import { Bell, CheckCircle, AlertCircle, FileText, TrendingUp, Settings } from 'lucide-react';

export function Notifications() {
  const notifications = [
    {
      id: '1',
      type: 'transaction',
      title: 'Transaksi Pembelian Baru',
      message: 'BBCA - Pembelian 100 lot @ Rp 9,500',
      security: 'Mandiri Sekuritas',
      time: '2 jam yang lalu',
      read: false,
      icon: TrendingUp,
      color: 'blue',
    },
    {
      id: '2',
      type: 'import',
      title: 'File Import Berhasil',
      message: '15 transaksi berhasil diimport dari file mandiri_trades_march_2026.csv',
      security: 'Mandiri Sekuritas',
      time: '5 jam yang lalu',
      read: false,
      icon: FileText,
      color: 'green',
    },
    {
      id: '3',
      type: 'transaction',
      title: 'Transaksi Penjualan',
      message: 'BBRI - Penjualan 100 lot @ Rp 4,900',
      security: 'Indo Premier Sekuritas',
      time: '1 hari yang lalu',
      read: true,
      icon: TrendingUp,
      color: 'blue',
    },
    {
      id: '4',
      type: 'import',
      title: 'Import Sebagian Berhasil',
      message: '8 dari 10 transaksi berhasil diimport. 2 transaksi duplikat diabaikan.',
      security: 'BCA Sekuritas',
      time: '2 hari yang lalu',
      read: true,
      icon: AlertCircle,
      color: 'yellow',
    },
    {
      id: '5',
      type: 'transaction',
      title: 'Transaksi Pembelian Baru',
      message: 'TLKM - Pembelian 500 lot @ Rp 3,200',
      security: 'Mandiri Sekuritas',
      time: '3 hari yang lalu',
      read: true,
      icon: TrendingUp,
      color: 'blue',
    },
  ];

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="space-y-4 lg:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 lg:gap-4">
        <div>
          <h1 className="text-xl lg:text-3xl font-bold text-gray-900">Notifikasi</h1>
          <p className="text-sm lg:text-base text-gray-600 mt-1">
            {unreadCount > 0 
              ? `${unreadCount} belum dibaca` 
              : 'Semua sudah dibaca'}
          </p>
        </div>
        <button className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors text-sm">
          <Settings className="w-4 h-4 lg:w-5 lg:h-5" />
          Pengaturan
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 lg:gap-4">
        <div className="bg-white rounded-lg lg:rounded-xl p-3 lg:p-6 border border-gray-200">
          <div className="flex items-center gap-2 lg:gap-3 mb-2">
            <div className="p-1.5 lg:p-2 bg-blue-100 rounded-lg">
              <Bell className="w-3 h-3 lg:w-5 lg:h-5 text-blue-600" />
            </div>
            <p className="text-xs lg:text-sm text-gray-600">Total</p>
          </div>
          <p className="text-lg lg:text-2xl font-bold text-gray-900">{notifications.length}</p>
        </div>
        <div className="bg-white rounded-lg lg:rounded-xl p-3 lg:p-6 border border-gray-200">
          <div className="flex items-center gap-2 lg:gap-3 mb-2">
            <div className="p-1.5 lg:p-2 bg-red-100 rounded-lg">
              <AlertCircle className="w-3 h-3 lg:w-5 lg:h-5 text-red-600" />
            </div>
            <p className="text-xs lg:text-sm text-gray-600">Baru</p>
          </div>
          <p className="text-lg lg:text-2xl font-bold text-gray-900">{unreadCount}</p>
        </div>
        <div className="bg-white rounded-lg lg:rounded-xl p-3 lg:p-6 border border-gray-200">
          <div className="flex items-center gap-2 lg:gap-3 mb-2">
            <div className="p-1.5 lg:p-2 bg-green-100 rounded-lg">
              <CheckCircle className="w-3 h-3 lg:w-5 lg:h-5 text-green-600" />
            </div>
            <p className="text-xs lg:text-sm text-gray-600">Dibaca</p>
          </div>
          <p className="text-lg lg:text-2xl font-bold text-gray-900">{notifications.length - unreadCount}</p>
        </div>
      </div>

      {/* Notifications List */}
      <div className="bg-white rounded-lg lg:rounded-xl border border-gray-200 divide-y divide-gray-200">
        {notifications.map((notification) => {
          const Icon = notification.icon;
          const bgColor = notification.read ? 'bg-white' : 'bg-blue-50';
          const iconBgColor = notification.color === 'blue' 
            ? 'bg-blue-100' 
            : notification.color === 'green'
            ? 'bg-green-100'
            : 'bg-yellow-100';
          const iconColor = notification.color === 'blue' 
            ? 'text-blue-600' 
            : notification.color === 'green'
            ? 'text-green-600'
            : 'text-yellow-600';

          return (
            <div key={notification.id} className={`p-4 lg:p-6 hover:bg-gray-50 transition-colors ${bgColor}`}>
              <div className="flex items-start gap-3 lg:gap-4">
                <div className={`p-2 lg:p-3 rounded-lg ${iconBgColor} flex-shrink-0`}>
                  <Icon className={`w-4 h-4 lg:w-6 lg:h-6 ${iconColor}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-sm lg:text-base text-gray-900">{notification.title}</h3>
                        {!notification.read && (
                          <span className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0"></span>
                        )}
                      </div>
                      <p className="text-xs lg:text-sm text-gray-600 mt-1">{notification.message}</p>
                      <div className="flex items-center gap-2 lg:gap-4 mt-2 lg:mt-3">
                        <span className="text-xs text-gray-500 truncate">{notification.security}</span>
                        <span className="text-gray-300">•</span>
                        <span className="text-xs text-gray-500">{notification.time}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Info */}
      <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg lg:rounded-xl p-4 lg:p-6 border border-blue-200">
        <div className="flex items-start gap-3 lg:gap-4">
          <div className="p-2 lg:p-3 bg-white rounded-lg flex-shrink-0">
            <Bell className="w-5 h-5 lg:w-6 lg:h-6 text-blue-600" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-gray-900 mb-2">Pengaturan Notifikasi</h3>
            <p className="text-xs lg:text-sm text-gray-700 leading-relaxed">
              Terima notifikasi otomatis dari sekuritas melalui email atau API.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}