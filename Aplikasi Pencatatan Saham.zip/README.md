
  # Aplikasi Pencatatan Saham

  This is a code bundle for Aplikasi Pencatatan Saham. The original project is available at https://www.figma.com/design/8QIYKDySu2UFas3ho0RXBL/Aplikasi-Pencatatan-Saham.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  