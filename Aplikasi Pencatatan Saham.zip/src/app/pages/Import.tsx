import { Upload, FileText, CheckCircle, AlertCircle, Download } from 'lucide-react';
import { useState } from 'react';
import { mockSecurities } from '../data/mockData';

export function Import() {
  const [selectedSecurity, setSelectedSecurity] = useState('');
  const [isDragging, setIsDragging] = useState(false);

  const importHistory = [
    {
      id: '1',
      fileName: 'mandiri_trades_march_2026.csv',
      securityName: 'Mandiri Sekuritas',
      recordCount: 15,
      status: 'success',
      date: '2026-04-05T10:30:00',
    },
    {
      id: '2',
      fileName: 'bca_sekuritas_feb_2026.xlsx',
      securityName: 'BCA Sekuritas',
      recordCount: 23,
      status: 'success',
      date: '2026-04-01T14:20:00',
    },
    {
      id: '3',
      fileName: 'ipot_trades_jan.csv',
      securityName: 'Indo Premier Sekuritas',
      recordCount: 8,
      status: 'partial',
      date: '2026-03-28T09:15:00',
    },
  ];

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    // Handle file drop
  };

  return (
    <div className="space-y-4 lg:space-y-6">
      <div>
        <h1 className="text-xl lg:text-3xl font-bold text-gray-900">Import Transaksi</h1>
        <p className="text-sm lg:text-base text-gray-600 mt-1">Upload file dari sekuritas</p>
      </div>

      {/* Upload Section */}
      <div className="space-y-4 lg:space-y-6">
        {/* Security Selection */}
        <div className="bg-white rounded-lg lg:rounded-xl p-4 lg:p-6 border border-gray-200">
          <label className="block text-sm font-medium text-gray-900 mb-3">
            Pilih Sekuritas
          </label>
          <select
            value={selectedSecurity}
            onChange={(e) => setSelectedSecurity(e.target.value)}
            className="w-full px-4 py-3 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">-- Pilih Sekuritas --</option>
            {mockSecurities.map((security) => (
              <option key={security.id} value={security.id}>
                {security.name} ({security.code})
              </option>
            ))}
          </select>
        </div>

        {/* File Upload */}
        <div className="bg-white rounded-lg lg:rounded-xl p-4 lg:p-6 border border-gray-200">
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl p-8 lg:p-12 text-center transition-colors ${
              isDragging
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-300'
            }`}
          >
            <div className="flex flex-col items-center gap-3 lg:gap-4">
              <div className="w-12 h-12 lg:w-16 lg:h-16 bg-blue-100 rounded-full flex items-center justify-center">
                <Upload className="w-6 h-6 lg:w-8 lg:h-8 text-blue-600" />
              </div>
              <div>
                <p className="text-base lg:text-lg font-semibold text-gray-900 mb-1">
                  Drag & drop file atau
                </p>
                <label className="text-blue-600 font-medium cursor-pointer hover:text-blue-700 text-sm lg:text-base">
                  Browse file
                  <input type="file" className="hidden" accept=".csv,.xlsx,.xls" />
                </label>
              </div>
              <p className="text-xs lg:text-sm text-gray-500">
                CSV, XLS, XLSX (maks 10MB)
              </p>
            </div>
          </div>

          <div className="mt-4 lg:mt-6">
            <button
              disabled={!selectedSecurity}
              className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed text-sm lg:text-base"
            >
              Upload & Process
            </button>
          </div>
        </div>

        {/* Instructions - Mobile Optimized */}
        <div className="bg-white rounded-lg lg:rounded-xl p-4 lg:p-6 border border-gray-200">
          <h3 className="font-semibold text-gray-900 mb-3">Format File</h3>
          <div className="space-y-2 text-xs lg:text-sm text-gray-600">
            <p>File harus memiliki kolom:</p>
            <ul className="list-disc list-inside space-y-1 ml-2">
              <li>Tanggal, Kode & Nama Saham</li>
              <li>Tipe (Beli/Jual)</li>
              <li>Jumlah Lot, Harga, Fee, Total</li>
            </ul>
          </div>
          <button className="w-full mt-4 inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-50 text-blue-700 rounded-lg font-medium hover:bg-blue-100 transition-colors border border-blue-200 text-sm">
            <Download className="w-4 h-4" />
            Download Template
          </button>
        </div>
      </div>

      {/* Import History */}
      <div className="bg-white rounded-lg lg:rounded-xl border border-gray-200 overflow-hidden">
        <div className="p-4 lg:p-6 border-b border-gray-200">
          <h3 className="font-semibold text-gray-900">Riwayat Import</h3>
        </div>
        <div className="divide-y divide-gray-200">
          {importHistory.map((history) => (
            <div key={history.id} className="p-4 lg:p-6 hover:bg-gray-50 transition-colors">
              <div className="flex items-start gap-3 lg:gap-4">
                <div className={`p-2 lg:p-3 rounded-lg flex-shrink-0 ${
                  history.status === 'success' 
                    ? 'bg-green-100' 
                    : 'bg-yellow-100'
                }`}>
                  {history.status === 'success' ? (
                    <CheckCircle className="w-5 h-5 lg:w-6 lg:h-6 text-green-600" />
                  ) : (
                    <AlertCircle className="w-5 h-5 lg:w-6 lg:h-6 text-yellow-600" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-3 lg:gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <FileText className="w-3 h-3 lg:w-4 lg:h-4 text-gray-400 flex-shrink-0" />
                        <h4 className="font-semibold text-sm lg:text-base text-gray-900 truncate">{history.fileName}</h4>
                      </div>
                      <p className="text-xs lg:text-sm text-gray-600 mt-1">{history.securityName}</p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="text-xs lg:text-sm font-medium text-gray-900">
                        {history.recordCount} data
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(history.date).toLocaleDateString('id-ID', {
                          day: '2-digit',
                          month: 'short',
                        })}
                      </p>
                    </div>
                  </div>
                  <div className="mt-3">
                    <span className={`inline-flex items-center gap-1 px-2 lg:px-3 py-1 rounded-full text-xs font-semibold ${
                      history.status === 'success'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-yellow-100 text-yellow-700'
                    }`}>
                      {history.status === 'success' ? 'Berhasil' : 'Sebagian'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}