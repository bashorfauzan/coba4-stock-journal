import { useState } from 'react';
import { Plus, Download, Filter, Search } from 'lucide-react';
import { mockTransactions, mockSecurities } from '../data/mockData';
import { Transaction } from '../types';

export function Transactions() {
  const [filterType, setFilterType] = useState<'all' | 'buy' | 'sell'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTransactions = mockTransactions.filter(tx => {
    const matchesType = filterType === 'all' || tx.type === filterType;
    const matchesSearch = tx.stockCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         tx.stockName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  const totalBuy = mockTransactions
    .filter(tx => tx.type === 'buy')
    .reduce((sum, tx) => sum + tx.total, 0);

  const totalSell = mockTransactions
    .filter(tx => tx.type === 'sell')
    .reduce((sum, tx) => sum + tx.total, 0);

  return (
    <div className="space-y-4 lg:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 lg:gap-4">
        <div>
          <h1 className="text-xl lg:text-3xl font-bold text-gray-900">Transaksi</h1>
          <p className="text-sm lg:text-base text-gray-600 mt-1">Riwayat transaksi jual beli</p>
        </div>
        <button className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors text-sm">
          <Plus className="w-4 h-4 lg:w-5 lg:h-5" />
          Tambah
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-3 lg:gap-4">
        <div className="bg-white rounded-lg lg:rounded-xl p-3 lg:p-6 border border-gray-200">
          <p className="text-xs lg:text-sm text-gray-600 mb-1">Total</p>
          <p className="text-lg lg:text-2xl font-bold text-gray-900">{mockTransactions.length}</p>
        </div>
        <div className="bg-white rounded-lg lg:rounded-xl p-3 lg:p-6 border border-gray-200">
          <p className="text-xs lg:text-sm text-gray-600 mb-1">Pembelian</p>
          <p className="text-sm lg:text-2xl font-bold text-green-600 truncate">{formatCurrency(totalBuy)}</p>
        </div>
        <div className="bg-white rounded-lg lg:rounded-xl p-3 lg:p-6 border border-gray-200">
          <p className="text-xs lg:text-sm text-gray-600 mb-1">Penjualan</p>
          <p className="text-sm lg:text-2xl font-bold text-red-600 truncate">{formatCurrency(totalSell)}</p>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white rounded-lg lg:rounded-xl p-3 lg:p-4 border border-gray-200">
        <div className="flex flex-col gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 lg:w-5 lg:h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Cari saham..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 lg:pl-10 pr-4 py-2 lg:py-2.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setFilterType('all')}
              className={`flex-1 px-3 lg:px-4 py-2 lg:py-2.5 rounded-lg font-medium transition-colors text-sm ${
                filterType === 'all'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700'
              }`}
            >
              Semua
            </button>
            <button
              onClick={() => setFilterType('buy')}
              className={`flex-1 px-3 lg:px-4 py-2 lg:py-2.5 rounded-lg font-medium transition-colors text-sm ${
                filterType === 'buy'
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-100 text-gray-700'
              }`}
            >
              Beli
            </button>
            <button
              onClick={() => setFilterType('sell')}
              className={`flex-1 px-3 lg:px-4 py-2 lg:py-2.5 rounded-lg font-medium transition-colors text-sm ${
                filterType === 'sell'
                  ? 'bg-red-600 text-white'
                  : 'bg-gray-100 text-gray-700'
              }`}
            >
              Jual
            </button>
          </div>
        </div>
      </div>

      {/* Transactions List - Mobile Optimized */}
      <div className="bg-white rounded-lg lg:rounded-xl border border-gray-200 overflow-hidden">
        <div className="divide-y divide-gray-200">
          {filteredTransactions.map((tx) => {
            const security = mockSecurities.find(s => s.id === tx.securityId);
            return (
              <div key={tx.id} className="p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="font-bold text-gray-900">{tx.stockCode}</h4>
                      <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-semibold ${
                        tx.type === 'buy'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-red-100 text-red-700'
                      }`}>
                        {tx.type === 'buy' ? 'Beli' : 'Jual'}
                      </span>
                    </div>
                    <p className="text-xs text-gray-600 mt-1 truncate">{tx.stockName}</p>
                    <div className="flex items-center gap-2 mt-2 text-xs text-gray-500">
                      <span>{tx.quantity} lot</span>
                      <span>•</span>
                      <span>@{tx.price.toLocaleString('id-ID')}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: security?.color }}></div>
                      <p className="text-xs text-gray-400">
                        {new Date(tx.date).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })}
                      </p>
                      <span className="text-gray-300">•</span>
                      <p className="text-xs text-gray-400">{security?.code}</p>
                    </div>
                    {tx.notes && (
                      <p className="text-xs text-blue-600 mt-2">{tx.notes}</p>
                    )}
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className="text-sm lg:text-base font-bold text-gray-900">
                      {formatCurrency(tx.total)}
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      Fee: {formatCurrency(tx.fee)}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}