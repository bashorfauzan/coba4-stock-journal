import { createBrowserRouter } from 'react-router';
import { Layout } from './pages/Layout';
import { Dashboard } from './pages/Dashboard';
import { Transactions } from './pages/Transactions';
import { Securities } from './pages/Securities';
import { Import } from './pages/Import';
import { Notifications } from './pages/Notifications';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Layout,
    children: [
      { index: true, Component: Dashboard },
      { path: 'transactions', Component: Transactions },
      { path: 'securities', Component: Securities },
      { path: 'import', Component: Import },
      { path: 'notifications', Component: Notifications },
    ],
  },
]);
