import { LayoutDashboard, ArrowLeftRight, Building2, Upload, Bell } from 'lucide-react';
import { NavLink } from 'react-router';

export function Sidebar() {
  const menuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
    { icon: ArrowLeftRight, label: 'Transaksi', path: '/transactions' },
    { icon: Building2, label: 'Sekuritas', path: '/securities' },
    { icon: Upload, label: 'Import', path: '/import' },
    { icon: Bell, label: 'Notifikasi', path: '/notifications' },
  ];

  return (
    <aside className="hidden lg:flex flex-col w-64 bg-white border-r border-gray-200 fixed h-full">
      <div className="p-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl flex items-center justify-center">
            <ArrowLeftRight className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-xl text-gray-900">StockJournal</h1>
            <p className="text-xs text-gray-500">Pencatatan Saham</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 px-3">
        {menuItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-lg mb-1 transition-all ${
                isActive
                  ? 'bg-blue-50 text-blue-700 font-medium'
                  : 'text-gray-600 hover:bg-gray-50'
              }`
            }
          >
            <item.icon className="w-5 h-5" />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="p-4 border-t border-gray-200">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-4">
          <p className="text-sm font-medium text-gray-900 mb-1">Pro Tips</p>
          <p className="text-xs text-gray-600">
            Import file transaksi dari sekuritas untuk pencatatan otomatis
          </p>
        </div>
      </div>
    </aside>
  );
}
