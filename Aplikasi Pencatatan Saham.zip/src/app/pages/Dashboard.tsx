import { TrendingUp, TrendingDown, Wallet, PieChart, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { StatCard } from '../components/StatCard';
import { AreaChart, Area, BarChart, Bar, PieChart as RePieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { mockTransactions, mockCurrentPrices, mockSecurities } from '../data/mockData';
import { PortfolioStock } from '../types';

export function Dashboard() {
  // Calculate portfolio
  const portfolio = calculatePortfolio();
  const summary = portfolio.summary;
  const stocks = portfolio.stocks;

  // Chart data
  const performanceData = [
    { month: 'Okt', value: 12500000 },
    { month: 'Nov', value: 14200000 },
    { month: 'Des', value: 13800000 },
    { month: 'Jan', value: 15600000 },
    { month: 'Feb', value: 17200000 },
    { month: 'Mar', value: 16800000 },
    { month: 'Apr', value: 18450000 },
  ];

  const transactionData = [
    { month: 'Okt', buy: 8, sell: 3 },
    { month: 'Nov', buy: 12, sell: 5 },
    { month: 'Des', buy: 6, sell: 7 },
    { month: 'Jan', buy: 10, sell: 4 },
    { month: 'Feb', buy: 15, sell: 6 },
    { month: 'Mar', buy: 9, sell: 8 },
    { month: 'Apr', buy: 7, sell: 2 },
  ];

  const stockDistribution = stocks.slice(0, 5).map(stock => ({
    name: stock.stockCode,
    value: stock.totalValue,
  }));

  const COLORS = ['#0066CC', '#00B4D8', '#E63946', '#F77F00', '#06D6A0'];

  return (
    <div className="space-y-4 lg:space-y-6">
      <div>
        <h1 className="text-xl lg:text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-sm lg:text-base text-gray-600 mt-1">Ringkasan portfolio Anda</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
        <StatCard
          title="Total Investasi"
          value={formatCurrency(summary.totalInvestment)}
          icon={Wallet}
          iconBg="bg-blue-600"
        />
        <StatCard
          title="Nilai Saat Ini"
          value={formatCurrency(summary.currentValue)}
          icon={PieChart}
          iconBg="bg-purple-600"
        />
        <StatCard
          title="Profit/Loss"
          value={formatCurrency(summary.totalProfitLoss)}
          change={`${summary.totalProfitLossPercentage >= 0 ? '+' : ''}${summary.totalProfitLossPercentage.toFixed(2)}%`}
          changeType={summary.totalProfitLoss >= 0 ? 'positive' : 'negative'}
          icon={summary.totalProfitLoss >= 0 ? TrendingUp : TrendingDown}
          iconBg={summary.totalProfitLoss >= 0 ? 'bg-green-600' : 'bg-red-600'}
        />
        <StatCard
          title="Total Saham"
          value={summary.totalStocks.toString()}
          icon={PieChart}
          iconBg="bg-orange-600"
        />
      </div>

      {/* Charts Row - Desktop Only */}
      <div className="hidden lg:grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Portfolio Performance */}
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <h3 className="font-semibold text-gray-900 mb-4">Performa Portfolio</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={performanceData}>
              <defs>
                <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0066CC" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#0066CC" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" tick={{ fill: '#666' }} />
              <YAxis tick={{ fill: '#666' }} />
              <Tooltip
                formatter={(value: number) => formatCurrency(value)}
                contentStyle={{ borderRadius: '8px', border: '1px solid #e5e7eb' }}
              />
              <Area
                type="monotone"
                dataKey="value"
                stroke="#0066CC"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorValue)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Transaction Activity */}
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <h3 className="font-semibold text-gray-900 mb-4">Aktivitas Transaksi</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={transactionData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" tick={{ fill: '#666' }} />
              <YAxis tick={{ fill: '#666' }} />
              <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #e5e7eb' }} />
              <Legend />
              <Bar dataKey="buy" fill="#00B4D8" name="Beli" radius={[8, 8, 0, 0]} />
              <Bar dataKey="sell" fill="#E63946" name="Jual" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Portfolio Holdings - Mobile Optimized */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="p-4 lg:p-6 border-b border-gray-200">
          <h3 className="font-semibold text-gray-900">Portfolio Saham</h3>
        </div>
        <div className="divide-y divide-gray-200">
          {stocks.slice(0, 5).map((stock, idx) => (
            <div key={idx} className="p-4 lg:p-6 hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-gray-900">{stock.stockCode}</h4>
                    <span className="text-xs text-gray-500">{stock.quantity} lot</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-0.5 truncate">{stock.stockName}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Avg: {stock.averagePrice.toLocaleString('id-ID')}
                  </p>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-sm font-bold text-gray-900">
                    {formatCurrency(stock.totalValue)}
                  </div>
                  <div className={`text-sm font-semibold mt-1 flex items-center justify-end gap-1 ${
                    stock.profitLoss >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {stock.profitLoss >= 0 ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                    {stock.profitLossPercentage >= 0 ? '+' : ''}{stock.profitLossPercentage.toFixed(2)}%
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Transactions - Mobile Optimized */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="p-4 lg:p-6 border-b border-gray-200 flex items-center justify-between">
          <h3 className="font-semibold text-gray-900">Transaksi Terbaru</h3>
          <a href="/transactions" className="text-sm text-blue-600 hover:text-blue-700 font-medium">
            Semua
          </a>
        </div>
        <div className="divide-y divide-gray-200">
          {mockTransactions.slice(0, 5).map((tx) => {
            const security = mockSecurities.find(s => s.id === tx.securityId);
            return (
              <div key={tx.id} className="p-4 lg:p-6 hover:bg-gray-50 transition-colors">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-gray-900">{tx.stockCode}</h4>
                      <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-semibold ${
                        tx.type === 'buy'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-red-100 text-red-700'
                      }`}>
                        {tx.type === 'buy' ? 'Beli' : 'Jual'}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {tx.quantity} lot @ {tx.price.toLocaleString('id-ID')}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      <p className="text-xs text-gray-400">
                        {new Date(tx.date).toLocaleDateString('id-ID', { day: '2-digit', month: 'short' })}
                      </p>
                      <span className="text-gray-300">•</span>
                      <p className="text-xs text-gray-400">{security?.code}</p>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className="text-sm font-bold text-gray-900">
                      {formatCurrency(tx.total)}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function calculatePortfolio() {
  const holdings = new Map<string, { quantity: number; totalCost: number; stockName: string }>();

  // Calculate holdings from transactions
  mockTransactions.forEach(tx => {
    const current = holdings.get(tx.stockCode) || { quantity: 0, totalCost: 0, stockName: tx.stockName };
    
    if (tx.type === 'buy') {
      current.quantity += tx.quantity;
      current.totalCost += tx.total;
    } else {
      const avgPrice = current.totalCost / current.quantity;
      current.quantity -= tx.quantity;
      current.totalCost -= avgPrice * tx.quantity;
    }
    
    holdings.set(tx.stockCode, current);
  });

  const stocks: PortfolioStock[] = [];
  let totalInvestment = 0;
  let currentValue = 0;

  holdings.forEach((holding, stockCode) => {
    if (holding.quantity > 0) {
      const averagePrice = holding.totalCost / holding.quantity;
      const currentPrice = mockCurrentPrices[stockCode] || averagePrice;
      const totalValue = currentPrice * holding.quantity;
      const profitLoss = totalValue - holding.totalCost;
      const profitLossPercentage = (profitLoss / holding.totalCost) * 100;

      stocks.push({
        stockCode,
        stockName: holding.stockName,
        quantity: holding.quantity,
        averagePrice,
        currentPrice,
        totalValue,
        profitLoss,
        profitLossPercentage,
      });

      totalInvestment += holding.totalCost;
      currentValue += totalValue;
    }
  });

  // Sort by total value
  stocks.sort((a, b) => b.totalValue - a.totalValue);

  const totalProfitLoss = currentValue - totalInvestment;
  const totalProfitLossPercentage = (totalProfitLoss / totalInvestment) * 100;

  return {
    stocks,
    summary: {
      totalInvestment,
      currentValue,
      totalProfitLoss,
      totalProfitLossPercentage,
      totalStocks: stocks.length,
    },
  };
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}