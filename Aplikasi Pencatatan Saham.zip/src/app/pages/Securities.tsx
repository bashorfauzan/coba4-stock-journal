import { Plus, Building2, TrendingUp, ArrowLeftRight } from 'lucide-react';
import { mockSecurities, mockTransactions } from '../data/mockData';

export function Securities() {
  const securitiesWithStats = mockSecurities.map(security => {
    const transactions = mockTransactions.filter(tx => tx.securityId === security.id);
    const buyCount = transactions.filter(tx => tx.type === 'buy').length;
    const sellCount = transactions.filter(tx => tx.type === 'sell').length;
    const totalValue = transactions.reduce((sum, tx) => sum + tx.total, 0);

    return {
      ...security,
      transactionCount: transactions.length,
      buyCount,
      sellCount,
      totalValue,
    };
  });

  return (
    <div className="space-y-4 lg:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 lg:gap-4">
        <div>
          <h1 className="text-xl lg:text-3xl font-bold text-gray-900">Sekuritas</h1>
          <p className="text-sm lg:text-base text-gray-600 mt-1">Kelola akun sekuritas</p>
        </div>
        <button className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors text-sm">
          <Plus className="w-4 h-4 lg:w-5 lg:h-5" />
          Tambah
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-3 lg:gap-4">
        <div className="bg-white rounded-lg lg:rounded-xl p-3 lg:p-6 border border-gray-200">
          <div className="flex items-center gap-2 lg:gap-3 mb-2 lg:mb-3">
            <div className="p-1.5 lg:p-2 bg-blue-100 rounded-lg">
              <Building2 className="w-3 h-3 lg:w-5 lg:h-5 text-blue-600" />
            </div>
            <p className="text-xs lg:text-sm text-gray-600">Total</p>
          </div>
          <p className="text-lg lg:text-2xl font-bold text-gray-900">{mockSecurities.length}</p>
        </div>
        <div className="bg-white rounded-lg lg:rounded-xl p-3 lg:p-6 border border-gray-200">
          <div className="flex items-center gap-2 lg:gap-3 mb-2 lg:mb-3">
            <div className="p-1.5 lg:p-2 bg-green-100 rounded-lg">
              <ArrowLeftRight className="w-3 h-3 lg:w-5 lg:h-5 text-green-600" />
            </div>
            <p className="text-xs lg:text-sm text-gray-600">Transaksi</p>
          </div>
          <p className="text-lg lg:text-2xl font-bold text-gray-900">{mockTransactions.length}</p>
        </div>
        <div className="bg-white rounded-lg lg:rounded-xl p-3 lg:p-6 border border-gray-200">
          <div className="flex items-center gap-2 lg:gap-3 mb-2 lg:mb-3">
            <div className="p-1.5 lg:p-2 bg-purple-100 rounded-lg">
              <TrendingUp className="w-3 h-3 lg:w-5 lg:h-5 text-purple-600" />
            </div>
            <p className="text-xs lg:text-sm text-gray-600">Aktif</p>
          </div>
          <p className="text-lg lg:text-2xl font-bold text-gray-900">{mockSecurities.length}</p>
        </div>
      </div>

      {/* Securities Grid */}
      <div className="grid grid-cols-1 gap-4 lg:gap-6">
        {securitiesWithStats.map((security) => (
          <div key={security.id} className="bg-white rounded-lg lg:rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow">
            <div className="p-4 lg:p-6 border-b border-gray-200" style={{ borderTopColor: security.color, borderTopWidth: '3px' }}>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3 lg:gap-4 flex-1 min-w-0">
                  <div className="w-12 h-12 lg:w-14 lg:h-14 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: security.color + '20' }}>
                    <Building2 className="w-6 h-6 lg:w-7 lg:h-7" style={{ color: security.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-base lg:text-lg text-gray-900 truncate">{security.name}</h3>
                    <p className="text-sm text-gray-600 mt-0.5">{security.code}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 lg:p-6">
              <div className="grid grid-cols-3 gap-3 lg:gap-4">
                <div>
                  <p className="text-xs text-gray-600 mb-1">Transaksi</p>
                  <p className="text-lg lg:text-xl font-bold text-gray-900">{security.transactionCount}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-600 mb-1">Beli</p>
                  <p className="text-lg lg:text-xl font-bold text-green-600">{security.buyCount}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-600 mb-1">Jual</p>
                  <p className="text-lg lg:text-xl font-bold text-red-600">{security.sellCount}</p>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Total Nilai</span>
                  <span className="font-semibold text-gray-900 text-sm lg:text-base">{formatCurrency(security.totalValue)}</span>
                </div>
              </div>

              <div className="mt-4 flex gap-2">
                <button className="flex-1 px-3 lg:px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors text-sm">
                  Detail
                </button>
                <button className="flex-1 px-3 lg:px-4 py-2 bg-blue-50 text-blue-700 rounded-lg font-medium hover:bg-blue-100 transition-colors text-sm">
                  Import
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}