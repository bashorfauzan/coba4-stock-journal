import { LayoutDashboard, ArrowLeftRight, Building2, Upload, Bell } from 'lucide-react';
import { NavLink } from 'react-router';

export function MobileNav() {
  const menuItems = [
    { icon: LayoutDashboard, label: 'Home', path: '/' },
    { icon: ArrowLeftRight, label: 'Transaksi', path: '/transactions' },
    { icon: Building2, label: 'Sekuritas', path: '/securities' },
    { icon: Upload, label: 'Import', path: '/import' },
    { icon: Bell, label: 'Notif', path: '/notifications' },
  ];

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50 safe-bottom">
      <nav className="flex items-center justify-around px-1 py-1.5">
        {menuItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-lg transition-all min-w-0 ${
                isActive ? 'text-blue-700' : 'text-gray-500'
              }`
            }
          >
            <item.icon className="w-5 h-5 flex-shrink-0" />
            <span className="text-[10px] font-medium truncate w-full text-center">{item.label}</span>
          </NavLink>
        ))}
      </nav>
    </div>
  );
}